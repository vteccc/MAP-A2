package Model.Type;

public interface Type {
    boolean equals(Object another);

    String toString();
}
