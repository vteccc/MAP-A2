package Model.ADT;

public interface MyInterfaceList<T> {
    void add(T v);

    String toString();
}
